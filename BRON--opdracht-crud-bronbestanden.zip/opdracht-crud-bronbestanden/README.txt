Plaats de twee controllers in de App\Http\Controllers map
Plaats de twee migrations in de database/migrations map
Plaats de web routes in de routes map
Plaats de views in de views map