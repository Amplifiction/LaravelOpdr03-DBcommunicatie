<?php $__env->startSection('title', 'Add new publisher'); ?>

<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('publishers.includes.back-to-list', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <h2 class="text-4xl font-semibold mb-4">Add new publisher</h2>

    <form class="bg-gray-100 shadow-2xl p-4 rounded-lg" action="<?php echo e(route('publishers.store')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <?php echo $__env->make('publishers.includes.form', [
            'buttonText' => 'Add new publisher',
            // 'publisher' => $publisher
        ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\LaravelOpdr03-DBcommunicatie\resources\views/publishers/create.blade.php ENDPATH**/ ?>