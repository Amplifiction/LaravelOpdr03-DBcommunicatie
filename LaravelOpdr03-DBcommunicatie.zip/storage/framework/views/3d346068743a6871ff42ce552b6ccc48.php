<table class="w-full text-left shadow-2xl">
    <tr class="bg-gray-300">
        <th class="p-2">Publisher</th>
        <th class="p-2">Actions</th>
    </tr>
    <?php $__empty_1 = true; $__currentLoopData = $publishers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $publisher): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <?php echo $__env->make('publishers.includes.publisher-row', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <p>No Publishers added yet.</p>
    <?php endif; ?>
</table>
<?php /**PATH C:\laragon\www\LaravelOpdr03-DBcommunicatie\resources\views/publishers/includes/publisher-table.blade.php ENDPATH**/ ?>