<?php $__env->startSection('title', 'Game: Game title here'); ?>

<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('games.includes.back-to-list', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <h2 class="text-4xl font-semibold mb-4"><?php echo e($game->name); ?></h2>
    <p class="text-lg text-gray-600 mb-4">Published by <a class="font-semibold text-blue-500 hover:underline" href="<?php echo e(route('publishers.show', $game->publisher->id)); ?>"><?php echo e($game->publisher->name); ?></a></p>

    <div class="my-4">
        <?php echo $__env->make('games.includes.actions', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>

    <?php if($game->completed): ?>
        <p class="p-4 inline-block bg-green-100 text-green-600 rounded-xl">This game has already been completed!</p>
    <?php else: ?>
        <p class="p-4 inline-block bg-red-100 text-red-600 rounded-xl">This game is not completed yet!</p>
    <?php endif; ?>

    <div class="mt-12">
        <h3 class="mb-2 text-xl font-semibold">Other games by this publisher:</h3>
        <?php echo $__env->make('games.includes.game-table', ['games' => $games], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\LaravelOpdr03-DBcommunicatie\resources\views/games/show.blade.php ENDPATH**/ ?>