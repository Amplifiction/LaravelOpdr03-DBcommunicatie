<?php if(!$game->completed): ?>
    <a class="px-4 py-1 bg-green-200 hover:bg-green-300 text-green-500 hover:text-green-600" href="<?php echo e(route('games.complete', $game)); ?>">Mark as complete</a>
<?php else: ?>
    <a class="px-4 py-1 bg-red-200 hover:bg-red-300 text-red-500 hover:text-red-600" href="<?php echo e(route('games.complete', $game)); ?>">Mark as incomplete</a>
<?php endif; ?>
<a class="px-4 py-1 bg-orange-200 hover:bg-orange-300 text-orange-500 hover:text-orange-600" href="<?php echo e(route('games.edit', $game)); ?>">Edit</a>
<a class="px-4 py-1 bg-red-200 hover:bg-red-300 text-red-500 hover:text-red-600" href="<?php echo e(route('games.delete', $game)); ?>">Delete</a>
<?php /**PATH C:\laragon\www\LaravelOpdr03-DBcommunicatie\resources\views/games/includes/actions.blade.php ENDPATH**/ ?>