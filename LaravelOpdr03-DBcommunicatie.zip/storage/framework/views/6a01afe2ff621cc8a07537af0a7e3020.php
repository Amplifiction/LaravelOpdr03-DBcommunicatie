<?php $__env->startSection('title', 'Publisher: Publisher name here'); ?>

<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('publishers.includes.back-to-list', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <h2 class="text-4xl font-semibold mb-4"><?php echo e($publisher->name); ?></h2>

    <div class="my-4">
        <?php echo $__env->make('publishers.includes.actions', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>

    <div class="mt-12">
        <h3 class="mb-2 text-xl font-semibold">Games created by this publisher:</h3>
        <?php echo $__env->make('games.includes.game-table', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\LaravelOpdr03-DBcommunicatie\resources\views/publishers/show.blade.php ENDPATH**/ ?>