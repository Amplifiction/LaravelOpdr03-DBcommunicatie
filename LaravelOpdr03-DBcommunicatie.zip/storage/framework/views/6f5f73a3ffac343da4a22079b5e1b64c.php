<tr class="even:bg-gray-100 odd:bg-gray-200">
    <td class="p-2 text-lg flex flex-col">
        <a href="<?php echo e(route('publishers.show', ['publisher' => $publisher])); ?>" class="hover:underline"><?php echo e($publisher->name); ?></a>
        <span class="text-gray-500 text-sm"><?php echo e($publisher->games->count()); ?> game<?php echo e($publisher->games->count()<>1?'s':''); ?></span>
    </td>
    <td class="p-2">
        <a href="<?php echo e(route('publishers.show', $publisher)); ?>" class="px-4 py-1 bg-blue-200 hover:bg-blue-300 text-blue-500 hover:text-blue-600">View</a>
        <?php echo $__env->make('publishers.includes.actions', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </td>
</tr>
<?php /**PATH C:\laragon\www\LaravelOpdr03-DBcommunicatie\resources\views/publishers/includes/publisher-row.blade.php ENDPATH**/ ?>