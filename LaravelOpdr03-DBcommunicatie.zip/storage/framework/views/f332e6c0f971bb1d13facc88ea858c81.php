<div class="py-4 flex items-center gap-2">
    <a class="bg-blue-200 hover:bg-blue-300 text-blue-600 px-4 py-2 inline-block" href="<?php echo e(route('games.index')); ?>">&larr; Back to list</a>

    <?php if($showLink ?? false): ?> 
        <a class="bg-blue-200 hover:bg-blue-300 text-blue-600 px-4 py-2 inline-block" href="<?php echo e(route('games.show', $game )); ?>">&larr; Back to game</a>
    <?php endif; ?>
</div>
<?php /**PATH C:\laragon\www\LaravelOpdr03-DBcommunicatie\resources\views/games/includes/back-to-list.blade.php ENDPATH**/ ?>