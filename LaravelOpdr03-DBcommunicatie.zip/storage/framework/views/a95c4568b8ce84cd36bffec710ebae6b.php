<tr class="even:bg-gray-100 odd:bg-gray-200">
    <td class="p-2">
        <?php if($game->completed): ?>
            <span class="text-green-500 font-semibold">&checkmark;</span>
        <?php else: ?>
            <span class="text-red-500 font-semibold">&times;</span>
        <?php endif; ?>
    </td>
    <td class="p-2 text-lg">
        <a href="<?php echo e(route('games.show', $game)); ?>" class="hover:underline"><?php echo e($game->name); ?></a>
    </td>
    <td class="p-2 text-gray-500">
        <a href="<?php echo e(route('publishers.show', ['publisher' => $game->publisher])); ?>" class="hover:underline"><?php echo e($game->publisher->name); ?></a>
    </td>
    <td class="p-2">
        <a href="<?php echo e(route('games.show', $game)); ?>" class="px-4 py-1 bg-blue-200 hover:bg-blue-300 text-blue-500 hover:text-blue-600">View</a>
        <?php echo $__env->make('games.includes.actions', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </td>
</tr>
<?php /**PATH C:\laragon\www\LaravelOpdr03-DBcommunicatie\resources\views/games/includes/game-row.blade.php ENDPATH**/ ?>