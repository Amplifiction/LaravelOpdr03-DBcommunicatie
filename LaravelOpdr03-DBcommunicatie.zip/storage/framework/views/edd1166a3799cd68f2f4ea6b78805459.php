<table class="w-full text-left shadow-2xl">
    <tr class="bg-gray-300">
        <th class="p-2 w-4"></th>
        <th class="p-2">Game</th>
        <th class="p-2">Publisher</th>
        <th class="p-2">Actions</th>
    </tr>
    <?php $__empty_1 = true; $__currentLoopData = $games; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $game): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <?php echo $__env->make('games.includes.game-row', ['game' => $game], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <p>No games added yet.</p>
    <?php endif; ?>
</table>
<?php /**PATH C:\laragon\www\LaravelOpdr03-DBcommunicatie\resources\views/games/includes/game-table.blade.php ENDPATH**/ ?>